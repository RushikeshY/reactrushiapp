<h1 align="center"><b>SWASHA-ECOMMERCE</b></h1>

<br />

<p align="center">
<img align="center" src="https://img.icons8.com/fluency/48/000000/node-js.png"/>
<img align="center" src="https://i.imgur.com/t1LI2Zy.png"/> 
<img align="center" src="https://img.icons8.com/nolan/48/express-js.png"/>
<img align="center" src="https://i.imgur.com/t1LI2Zy.png"/> 
<img align="center" src="https://img.icons8.com/color/48/000000/mongodb.png"/>
</p>

<br />

<h1 align="center"><b>API Reference</b></h1>

- ### [***SWASHA DOC.- Notion***](https://melodic-atlasaurus-f4d.notion.site/Swasha-Doc-a04b915d0a1d427ba2016c3f0d122eae)
- ### [ ***AUTHENTICAION APIs***](https://github.com/Nirmaan-Organization/Swasha-Backend/blob/main/documentation/auth.md)
- ### [ ***PRODUCT APIs*** ](https://github.com/Nirmaan-Organization/Swasha-Backend/blob/main/documentation/product.md)
