const footerHTML=`
</div>
</div>
<table class="email-footer">
<tr>
  <td align="center">
    <a target="_blank" href="https://www.facebook.com/profile.php?id=100091939407370">
      <img src="https://swasha.org/png/facebook.png" height="14" width="auto" style="padding-left:10px;padding-right:10px;">
    </a>
    <a target="_blank" href="https://www.instagram.com/swasha_handicrafts/">
      <img src="https://swasha.org/png/instagram.png" height="14" width="auto" style="padding-left:10px;padding-right:10px;">
    </a>
    <a target="_blank" href="https://www.linkedin.com/in/swasha-handicrafts-148b68274/">
      <img src="https://swasha.org/png/linkedin.png" height="14" width="auto" style="padding-left:10px;padding-right:10px;">
    </a>
    <a target="_blank" href="https://twitter.com/SWASHACRAFTS/status/1655445622424743937">
      <img src="https://swasha.org/png/twitter.png" height="14" width="auto" style="padding-left:10px;padding-right:10px;">
    </a>
  </td>
</tr>
<tr>
  <td>
    SWASHA, derived from the word “SWAyam SHAkti”, embodies the essence of
    self-empowerment.
  </td>
</tr>
<tr>
  <td>
    For General Queries, contact us at contact@swasha.org
  </td>
</tr>
<tr>
  <td style="border-top: 1px dashed #9C9C9C;">
    H.No: 1-98/9/3, Flat No. 302, Plot No.3, Jaihind Enclave, Madhapur, Hyderabad, Telangana - 500081.
  </td>
</tr>
</table>
</div>
</body>
</html>`;
 module.exports=footerHTML