import React from 'react'

const Dashboard = () => {
  return (
    <div className='text-xl font-bold mb-4'>
      Dashboard
    </div>
  )
}

export default Dashboard